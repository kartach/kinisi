
DROP TABLE IF EXISTS `bc73q_acymailing_url`;
CREATE TABLE `bc73q_acymailing_url` (
  `urlid` int(10) UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `url` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
