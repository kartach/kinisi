
DROP TABLE IF EXISTS `bc73q_acymailing_listcampaign`;
CREATE TABLE `bc73q_acymailing_listcampaign` (
  `campaignid` smallint(5) UNSIGNED NOT NULL,
  `listid` smallint(5) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
