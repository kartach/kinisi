
DROP TABLE IF EXISTS `bc73q_acymailing_tagmail`;
CREATE TABLE `bc73q_acymailing_tagmail` (
  `tagid` smallint(5) UNSIGNED NOT NULL,
  `mailid` mediumint(8) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
