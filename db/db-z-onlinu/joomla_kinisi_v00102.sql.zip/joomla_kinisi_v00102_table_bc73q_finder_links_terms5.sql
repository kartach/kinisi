
DROP TABLE IF EXISTS `bc73q_finder_links_terms5`;
CREATE TABLE `bc73q_finder_links_terms5` (
  `link_id` int(10) UNSIGNED NOT NULL,
  `term_id` int(10) UNSIGNED NOT NULL,
  `weight` float UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `bc73q_finder_links_terms5` VALUES(184, 130916, 0.07);
INSERT INTO `bc73q_finder_links_terms5` VALUES(185, 130916, 0.07);
