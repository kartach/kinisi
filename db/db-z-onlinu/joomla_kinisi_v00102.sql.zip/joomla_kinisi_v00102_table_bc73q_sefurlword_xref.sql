
DROP TABLE IF EXISTS `bc73q_sefurlword_xref`;
CREATE TABLE `bc73q_sefurlword_xref` (
  `word` int(11) NOT NULL,
  `url` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
