
DROP TABLE IF EXISTS `bc73q_sefwords`;
CREATE TABLE `bc73q_sefwords` (
  `id` int(11) NOT NULL,
  `word` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
