
DROP TABLE IF EXISTS `bc73q_kunena_messages_text`;
CREATE TABLE `bc73q_kunena_messages_text` (
  `mesid` int(11) NOT NULL DEFAULT '0',
  `message` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `bc73q_kunena_messages_text` VALUES(12, 'ssssss');
INSERT INTO `bc73q_kunena_messages_text` VALUES(13, 'fff');
INSERT INTO `bc73q_kunena_messages_text` VALUES(14, 'ff');
INSERT INTO `bc73q_kunena_messages_text` VALUES(15, 'dddddddddd [attachment=2]4090408.jpeg[/attachment]');
INSERT INTO `bc73q_kunena_messages_text` VALUES(17, 'Ptám se????');
INSERT INTO `bc73q_kunena_messages_text` VALUES(18, 'Ptám se????');
INSERT INTO `bc73q_kunena_messages_text` VALUES(19, 'ss');
INSERT INTO `bc73q_kunena_messages_text` VALUES(20, 'dddd');
INSERT INTO `bc73q_kunena_messages_text` VALUES(21, 'xx');
INSERT INTO `bc73q_kunena_messages_text` VALUES(22, 'c');
INSERT INTO `bc73q_kunena_messages_text` VALUES(23, 'ssss');
INSERT INTO `bc73q_kunena_messages_text` VALUES(24, 'ss');
INSERT INTO `bc73q_kunena_messages_text` VALUES(25, 's');
INSERT INTO `bc73q_kunena_messages_text` VALUES(27, 'Dobrý den, \r\ngratuluji k novému webu! Jen poznámku, když už máte registraci, nebylo by dobrý mít i možnost komentářů pod článkama? Myslím si, že lidi by si zrovna u článků z tohoto oboru rádi vyměňovali názory.');
INSERT INTO `bc73q_kunena_messages_text` VALUES(29, 'Dobrý den, \r\nbydlím nedaleko a uvítala bych, kdybyste měli možnost skupinového cvičení maminek s dětma, aby svičení bylo zaměřeno na vývoj dítěte a my bychom se mohli něco dozvědět a zároveň si u toho zacvičit. Je to něco jinýho, než normální cvičení v různých kurzech a školičkách, když by to bylo pod vedenim fyzioterapeuta. Na stránkách jsem žádné informace o skupinovém cvičení nenašla. Pořádáte nějaké nebo plánujete je? Jaké? Děkuji.');
INSERT INTO `bc73q_kunena_messages_text` VALUES(30, 'Děkujeme za první postřeh a návrh. Naprosto s Vámi souhlasíme. S komentáři k jednotlivým článkům počítáme do další verze.');
INSERT INTO `bc73q_kunena_messages_text` VALUES(31, 'Dobrý den,\r\nprozatím skupinová cvičení neplánujeme. V centru Kinisi se zaměřujeme na individuální vedenou dětskou fyzioterapii šitou na míru daného dítěte, kde rodičům pečlivě všechno vysvětlíme. S pozdravem, Lenka Augustínová');
